ASSETS = ["robotics-display", "network-lab", "server-room"]

def list_assets():
    for asset in ASSETS:
        print(f"Registered asset: {asset}")

if __name__ == "__main__":
    list_assets()