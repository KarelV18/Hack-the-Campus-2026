# Campus Asset Tracker

This repository contains a small internal asset-tracking prototype.

The development team recently cleaned the repository before transferring it
to the incident-response team. Only current files should be present.